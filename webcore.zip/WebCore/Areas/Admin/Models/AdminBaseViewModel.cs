﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebCore.Services.Share.AdminMenus.Dto;
using WebCore.Services.Share.Admins.Languages.Dto;

namespace WebCore.Areas.Admin.Models
{
    public class AdminBaseViewModel
    {
        public string CurrentLanguage { get; set; }
        public AdminMenuTreeViewDto Menus { get; set; }
        
    }
}
