﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Diagnostics;
using System.Linq;
using WebCore.Entities;
using WebCore.EntityFramework.Repositories;
using WebCore.Models;
using WebCore.Services.Share.AppMenus;

namespace WebCore.Controllers
{
    public class HomeController : WebCoreBaseController
    {
        private readonly IAppMenuService appMenuService;
        private readonly IDistributedCache distributedCache;
        private readonly IMemoryCache memoryCache;

        private readonly IRepository<LanguageDetail, int> languageDetailRepository;

        public HomeController(IAppMenuService appMenuService, IDistributedCache distributedCache, IMemoryCache memoryCache, IRepository<LanguageDetail, int> languageDetailRepository)
        {
            this.appMenuService = appMenuService;
            this.distributedCache = distributedCache;
            this.memoryCache = memoryCache;
            this.languageDetailRepository = languageDetailRepository;
        }

        public IActionResult Index()
        {
            System.Collections.Generic.List<Services.Share.AppMenus.Dto.AppMenuDto> menus = appMenuService.GetAllMenuByPermission(GetAllPermissions().ToList());
            var lst = languageDetailRepository.GetAll().ToList();
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
