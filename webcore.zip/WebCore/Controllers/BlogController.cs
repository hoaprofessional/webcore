﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WebCore.Models;
using WebCore.Services.Share.Blogs;
using WebCore.Services.Share.Blogs.Dto;

namespace WebCore.Controllers
{
    public class BlogController : Controller
    {
        private IBlogService blogService;

        public BlogController(IBlogService blogService)
        {
            this.blogService = blogService;
        }

        public IActionResult Index(int id = 0)
        {
            var blog = blogService.GetById(id);
            return View(blog);
        }

        public IActionResult List(int page)
        {
            BlogFilterInput filterModel = null;
            string filter = HttpContext.Session.GetString("BlogFilter");
            if (filter == null)
            {
                filterModel = new BlogFilterInput();
            }
            else
            {
                filterModel = (BlogFilterInput)JsonConvert.DeserializeObject<BlogFilterInput>(filter);
            }
            filterModel.PageNumber = page;
            filterModel.PageSize = 4;
            BlogViewModel blogViewModel = new BlogViewModel();
            blogViewModel.BlogFilter = filterModel;
            blogViewModel.Blogs = blogService.GetBlogPaging(blogViewModel.BlogFilter);
            return View(blogViewModel);
        }

        [HttpPost]
        public IActionResult SaveFilter(BlogFilterInput filterObject)
        {
            string jsonString = JsonConvert.SerializeObject(filterObject);
            HttpContext.Session.SetString("BlogFilter", jsonString);
            return RedirectToAction("List", new { page = 1 });
        }

        public IActionResult SaveInput(BlogInput input)
        {
            blogService.SaveBlog(input);
            return Ok("sucess");
        }
    }
}