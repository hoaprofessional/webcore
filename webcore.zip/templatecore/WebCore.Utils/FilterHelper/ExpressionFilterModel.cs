﻿namespace WebCore.Utils.FilterHelper
{
    public class ExpressionFilterModel
    {
        public string PropertyName { get; set; }
        public object Value { get; set; }
        public FilterComparison Comparison { get; set; }
    }
}
