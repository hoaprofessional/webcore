﻿namespace WebCore.Utils.ModelHelper
{
    public interface IPagingFilterDto
    {
        int PageNumber { get; set; }
        int PageSize { get; set; }
    }
}
