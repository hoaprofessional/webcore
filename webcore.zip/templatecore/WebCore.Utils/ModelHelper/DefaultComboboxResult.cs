﻿namespace WebCore.Utils.ModelHelper
{
    public class DefaultComboboxResult : ComboboxResult<int, string>
    {
    }
}
