﻿namespace WebCore.Utils.ModelHelper
{
    public interface IPagingAndSortingFilterDto : IPagingFilterDto, ISortingFilterDto
    {
    }
}
