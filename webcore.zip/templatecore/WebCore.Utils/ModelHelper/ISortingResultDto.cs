﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebCore.Utils.ModelHelper
{
    public interface ISortingResultDto
    {
        string Sorting { get; set; }
    }
}
