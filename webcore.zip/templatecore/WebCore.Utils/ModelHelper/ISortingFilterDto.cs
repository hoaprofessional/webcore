﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebCore.Utils.ModelHelper
{
    public interface ISortingFilterDto 
    {
        string Sorting { get; set; }
    }
}
