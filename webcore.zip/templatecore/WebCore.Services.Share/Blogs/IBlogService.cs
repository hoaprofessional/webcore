﻿using System;
using System.Collections.Generic;
using System.Text;
using WebCore.Entities;
using WebCore.Services.Share.Blogs.Dto;
using WebCore.Utils.ModelHelper;

namespace WebCore.Services.Share.Blogs
{
    public interface IBlogService
    {
        void SaveBlog(BlogInput blogInput);
        BlogInput GetById(int id);

        PagingResultDto<BlogDto> GetBlogPaging(BlogFilterInput filter);
    }
}
