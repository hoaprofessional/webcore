﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;
using WebCore.Utils.ModelHelper;

namespace WebCore.Services.Share.Blogs.Dto
{
    //Blog
    public class BlogInput : EntityId<int>
    {
        [Required(ErrorMessage = "LBL_TITLE_REQUIRED")]
        public string Title { get; set; }
        public string Image { get; set; }
        [Required(ErrorMessage = "LBL_ShortDecription_REQUIRED")]
        public string ShortDecription { get; set; }
        public IFormFile FileUpload { get; set; }

    }
}
