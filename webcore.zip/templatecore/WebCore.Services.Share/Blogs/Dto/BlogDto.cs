﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebCore.Services.Share.Blogs.Dto
{
    //Blog
    public class BlogDto
    {
        public string Title { get; set; }
        public string Image { get; set; }
        public string ShortDecription { get; set; }
    }
}
