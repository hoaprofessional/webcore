﻿using System;
using System.Collections.Generic;
using System.Text;
using WebCore.Utils.FilterHelper;
using WebCore.Utils.ModelHelper;

namespace WebCore.Services.Share.Blogs.Dto
{
    // Blog
    public class BlogFilterInput : IPagingFilterDto
    {
        [Filter(FilterComparison.Equal)]
        public string Image { get; set; }
        [Filter(FilterComparison.Contains)]
        public string Title { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}
