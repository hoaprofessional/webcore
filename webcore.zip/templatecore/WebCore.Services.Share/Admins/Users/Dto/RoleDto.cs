﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebCore.Services.Share.Admins.Users.Dto
{
    // WebCoreRole
    public class RoleDto
    {
        public string RoleName { get; set; }
        public bool IsChecked { get; set; }
    }
}
