﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebCore.Services.Share.Admins.Languages.Dto
{
    public class LanguageDto
    {
        public string LangCode { get; set; }
        public string LangName { get; set; }
    }
}
