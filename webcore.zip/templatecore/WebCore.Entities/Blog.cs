﻿using System;
using System.Collections.Generic;
using System.Text;
using WebCore.Utils.ModelHelper;

namespace WebCore.Entities
{
    public class Blog : Auditable
    {
        public string Title { get; set; }
        public string Image { get; set; }
        public string ShortDecription { get; set; }
    }
}
