﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using System.Linq;
using WebCore.Entities;
using WebCore.EntityFramework.Helper;
using WebCore.EntityFramework.Repositories;
using WebCore.Services.Share.Blogs;
using WebCore.Services.Share.Blogs.Dto;
using WebCore.Utils.CollectionHelper;
using WebCore.Utils.FilterHelper;
using WebCore.Utils.ModelHelper;

namespace WebCore.Services.Impl.Blogs
{
    public class BlogService : IBlogService
    {
        private readonly IRepository<Blog, int> blogRepository;
        private readonly IMapper mapper;
        private readonly IUnitOfWork unitOfWork;

        public BlogService(IRepository<Blog, int> blogRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            this.blogRepository = blogRepository;
            this.mapper = mapper;
            this.unitOfWork = unitOfWork;
        }

        public PagingResultDto<BlogDto> GetBlogPaging(BlogFilterInput filter)
        {
            var query = blogRepository.GetAll()
                                      .Filter(filter)
                                      .ProjectTo<BlogDto>(mapper.ConfigurationProvider);

            var s = query.ToList();
            return query.PagedQuery(filter);
        }

        public BlogInput GetById(int id)
        {
            Blog blog = blogRepository.GetById(id);
            return mapper.Map<BlogInput>(blog);
        }

        public void SaveBlog(BlogInput blogInput)
        {
            Blog model = blogRepository.GetById(blogInput.Id);
            if (model == null)
            {
                model = mapper.Map<Blog>(blogInput);
                blogRepository.Add(model);
            }
            else
            {
                mapper.Map(blogInput, model);
                blogRepository.Update(model);
            }
            unitOfWork.SaveChanges();
        }

    }
}
