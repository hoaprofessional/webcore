﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Microsoft.Extensions.Caching.Memory;
using System.Collections.Generic;
using System.Linq;
using WebCore.Entities;
using WebCore.EntityFramework.Repositories;
using WebCore.Services.Share.AdminMenus;
using WebCore.Services.Share.AdminMenus.Dto;
using WebCore.Utils.Config;
using WebCore.Utils.TreeViewHelper;

namespace WebCore.Services.Impl.AdminMenus
{
    public class AdminMenuProvider : IAdminMenuProvider
    {
        private IRepository<AdminMenu, int> adminMenuRepository;
        private readonly IMemoryCache memoryCache;
        private readonly IMapper mapper;

        public AdminMenuProvider(IRepository<AdminMenu, int> adminMenuRepository, IMapper mapper, IMemoryCache memoryCache)
        {
            this.adminMenuRepository = adminMenuRepository;
            this.mapper = mapper;
            this.memoryCache = memoryCache;
        }

        public AdminMenuTreeViewDto GetAdminMenuTreeView(string[] permissions, string currentLink)
        {
            List<AdminMenuTreeViewDto> adminMenus = GetAdminMenusInCache()
                                                    .Where(x => string.IsNullOrEmpty(x.Permission) || permissions.Contains(x.Permission)).ToList();
            adminMenus.ForEach(x =>
            {
                x.IsActive = (x.Link == currentLink);
            });
            return adminMenus.ToTreeView(0);
        }

        private List<AdminMenuTreeViewDto> GetAdminMenusInCache()
        {
            List<AdminMenuTreeViewDto> adminMenus = memoryCache.Get<List<AdminMenuTreeViewDto>>(ConstantConfig.MemoryCacheConfig.AdminMenuCache);
            if (adminMenus == null)
            {
                adminMenus = adminMenuRepository
                                .GetByCondition(x => x.RecordStatus == ConstantConfig.RecordStatusConfig.Active)
                                .OrderBy(x => x.OrderNo)
                                .ProjectTo<AdminMenuTreeViewDto>(mapper.ConfigurationProvider)
                                .ToList();
            }
            return adminMenus;
        }

        public void UpdateAdminMenuInCache(AdminMenu adminMenu)
        {
            List<AdminMenuTreeViewDto> adminMenuInCache = GetAdminMenusInCache();
            AdminMenuTreeViewDto adminMenuDto = adminMenuInCache.Where(x => x.Id == adminMenu.Id).FirstOrDefault();
            if (adminMenuDto == null)
            {
                adminMenuDto = mapper.Map<AdminMenuTreeViewDto>(adminMenu);
                adminMenuInCache.Add(adminMenuDto);
            }
            else
            {
                mapper.Map(adminMenu, adminMenuDto);
            }
        }
    }
}
