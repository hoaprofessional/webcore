﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using WebCore.Entities;
using WebCore.EntityFramework.Helper;
using WebCore.EntityFramework.Repositories;
using WebCore.Services.Share.Languages;
using WebCore.Services.Share.Languages.Dto;
using WebCore.Utils.Config;

namespace WebCore.Services.Impl.Languages
{
    public class LanguageProviderService : BaseService, ILanguageProviderService
    {
        private readonly IRepository<LanguageDetail, int> languageDetailRepository;
        private readonly IRepository<Language, int> languageRepository;
        private readonly IUnitOfWork unitOfWork;
        private readonly IMemoryCache memoryCache;
        private readonly IMapper mapper;
        public LanguageProviderService(IRepository<LanguageDetail, int> languageDetailRepository
            , IUnitOfWork unitOfWork
            , IMapper mapper
            , IMemoryCache memoryCache
            , IRepository<Language, int> languageRepository
            , IServiceProvider serviceProvider) :
            base(serviceProvider)
        {
            this.languageDetailRepository = languageDetailRepository;
            this.unitOfWork = unitOfWork;
            this.memoryCache = memoryCache;
            this.mapper = mapper;
            this.languageRepository = languageRepository;
        }

        public string GetlangByKey(string key)
        {
            // fix key
            if (!key.StartsWith("LBL_"))
            {
                key = "LBL_" + key.ToUpper();
            }
            else
            {
                key = key.ToUpper();
            }

            string currentLangCode = CultureInfo.CurrentCulture.Name;
            string langValue = "[" + key + "]";

            LanguageDetailDto langDetailDto = GetLanguageDetailInCache(currentLangCode, key);
            if (langDetailDto == null)
            {
                string[] allLangCodes = languageRepository.GetAll().Where(x => x.RecordStatus == ConstantConfig.RecordStatusConfig.Active).Select(x => x.LangCode).ToArray();
                foreach (string code in allLangCodes)
                {
                    LanguageDetail languageDetail = languageDetailRepository.GetFirstByCondition(x => x.LanguageCode == code && x.LanguageKey == key);
                    if (languageDetail == null)
                    {
                        languageDetail = new LanguageDetail()
                        {
                            LanguageCode = code,
                            LanguageKey = key,
                            LanguageValue = langValue,
                            CreatedBy = GetCurrentUserLogin(),
                            CreatedDate = DateTime.Now,
                            ModifiedDate = DateTime.Now
                        };
                        languageDetail = languageDetailRepository.Add(languageDetail);
                    }
                }
                unitOfWork.SaveChanges();

                langDetailDto = mapper.Map<LanguageDetailDto>(languageDetailRepository.GetFirstByCondition(x => x.LanguageCode == currentLangCode && x.LanguageKey == key));
                AddLanguageToCache(langDetailDto);
            }
            return langDetailDto.LanguageValue;
        }

        public void UpdateLanguage(string code, string key, string value)
        {
            List<LanguageDetailDto> langsInCache = GetLanguageInCache(code);
            LanguageDetail langDetail = languageDetailRepository.GetFirstByCondition(x => x.LanguageCode == code && x.LanguageKey == key);
            if (langDetail != null)
            {
                langDetail.LanguageValue = value;
                langDetail.UpdateToken = Guid.NewGuid();
                langDetail.ModifiedDate = DateTime.Now;
                langDetail.ModifiedBy = GetCurrentUserLogin();
                languageDetailRepository.Update(langDetail);
                unitOfWork.SaveChanges();
                LanguageDetailDto langDetailDto = mapper.Map<LanguageDetailDto>(langDetail);
                AddLanguageToCache(langDetailDto);
            }
        }

        private List<LanguageDetailDto> GetLanguageInCache(string code)
        {
            string cacheKey = ConstantConfig.MemoryCacheConfig.LanguageCache + code;
            List<LanguageDetailDto> languageInCache = memoryCache.Get<List<LanguageDetailDto>>(cacheKey);
            if (languageInCache == null)
            {
                IQueryable<LanguageDetailDto> dtoQuery = languageDetailRepository
                    .GetByCondition(x => x.LanguageCode == code)
                    .ProjectTo<LanguageDetailDto>(mapper.ConfigurationProvider);
                languageInCache = dtoQuery.ToList();
                memoryCache.Set(cacheKey, languageInCache);
            }
            return languageInCache;
        }
        private void AddLanguageToCache(LanguageDetailDto languageDetailDto)
        {
            List<LanguageDetailDto> languageInCache = GetLanguageInCache(languageDetailDto.LanguageCode);
            LanguageDetailDto lang = languageInCache.Where(x => x.LanguageKey == languageDetailDto.LanguageKey).FirstOrDefault();
            if (lang == null)
            {
                languageInCache.Add(languageDetailDto);
            }
            else
            {
                lang.LanguageValue = languageDetailDto.LanguageValue;
            }
        }
        private LanguageDetailDto GetLanguageDetailInCache(string code, string key)
        {
            List<LanguageDetailDto> languagesInCache = GetLanguageInCache(code);
            IEnumerable<LanguageDetailDto> result = languagesInCache.Where(x => x.LanguageCode == code && x.LanguageKey == key);
            return result.FirstOrDefault();
        }
        public List<LanguageDetailDto> GetLanguagesByCode(string code)
        {
            return GetLanguageInCache(code);
        }
    }
}
